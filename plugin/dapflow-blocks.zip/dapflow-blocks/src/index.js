/**
 * DapFlow Blocks
 * 
 * Entry point for all Gutenberg blocks
 */

import './styles/editor.scss';

// Import block registrations
import '../blocks/hero/index.js';

console.log('DapFlow Blocks loaded');

